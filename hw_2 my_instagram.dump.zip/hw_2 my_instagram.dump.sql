--
-- PostgreSQL database dump
--

-- Dumped from database version 12.10 (Debian 12.10-1.pgdg110+1)
-- Dumped by pg_dump version 12.10 (Debian 12.10-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: disslikes; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.disslikes (
    id integer NOT NULL,
    disslikes integer NOT NULL
);


ALTER TABLE public.disslikes OWNER TO gb_user;

--
-- Name: disslikes_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.disslikes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.disslikes_id_seq OWNER TO gb_user;

--
-- Name: disslikes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.disslikes_id_seq OWNED BY public.disslikes.id;


--
-- Name: likes; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.likes (
    id integer NOT NULL,
    likes integer NOT NULL
);


ALTER TABLE public.likes OWNER TO gb_user;

--
-- Name: likes_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.likes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.likes_id_seq OWNER TO gb_user;

--
-- Name: likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.likes_id_seq OWNED BY public.likes.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    url character varying(255),
    from_user_id integer,
    to_user_id integer,
    body text,
    is_important character varying(255) DEFAULT NULL::character varying,
    is_delivered character varying(255) DEFAULT NULL::character varying,
    created_at character varying(255)
);


ALTER TABLE public.messages OWNER TO gb_user;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.messages_id_seq OWNER TO gb_user;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: photo; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.photo (
    id integer NOT NULL,
    url character varying(255),
    owner_id integer,
    description text,
    uploaded_at character varying(255),
    size integer
);


ALTER TABLE public.photo OWNER TO gb_user;

--
-- Name: photo_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.photo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.photo_id_seq OWNER TO gb_user;

--
-- Name: photo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.photo_id_seq OWNED BY public.photo.id;


--
-- Name: publications; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.publications (
    id integer NOT NULL,
    photo_id integer NOT NULL,
    video_id integer NOT NULL,
    descriptions character varying(120),
    count_likes integer NOT NULL,
    count_disslikes integer NOT NULL
);


ALTER TABLE public.publications OWNER TO gb_user;

--
-- Name: publikations_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.publikations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.publikations_id_seq OWNER TO gb_user;

--
-- Name: publikations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.publikations_id_seq OWNED BY public.publications.id;


--
-- Name: status; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.status (
    id integer NOT NULL,
    status_text character varying(30)
);


ALTER TABLE public.status OWNER TO gb_user;

--
-- Name: status_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.status_id_seq OWNER TO gb_user;

--
-- Name: status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.status_id_seq OWNED BY public.status.id;


--
-- Name: subscriber; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.subscriber (
    id integer NOT NULL,
    name character varying(30)
);


ALTER TABLE public.subscriber OWNER TO gb_user;

--
-- Name: subscriber_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.subscriber_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriber_id_seq OWNER TO gb_user;

--
-- Name: subscriber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.subscriber_id_seq OWNED BY public.subscriber.id;


--
-- Name: subscription; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.subscription (
    id integer NOT NULL,
    requested_by_user_id integer NOT NULL,
    requested_to_user_id integer NOT NULL,
    status_id integer NOT NULL,
    requested_at timestamp without time zone,
    confirmed_at timestamp without time zone
);


ALTER TABLE public.subscription OWNER TO gb_user;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.subscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscription_id_seq OWNER TO gb_user;

--
-- Name: subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.subscription_id_seq OWNED BY public.subscription.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name character varying(255) DEFAULT NULL::character varying,
    last_name character varying(255) DEFAULT NULL::character varying,
    email character varying(255) DEFAULT NULL::character varying,
    phone character varying(100) DEFAULT NULL::character varying,
    main_photo_id integer,
    created_at character varying(255)
);


ALTER TABLE public.users OWNER TO gb_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO gb_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: video; Type: TABLE; Schema: public; Owner: gb_user
--

CREATE TABLE public.video (
    id integer NOT NULL,
    url character varying(255),
    owner_id integer,
    description text,
    uploaded_at character varying(255),
    size integer
);


ALTER TABLE public.video OWNER TO gb_user;

--
-- Name: video_id_seq; Type: SEQUENCE; Schema: public; Owner: gb_user
--

CREATE SEQUENCE public.video_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.video_id_seq OWNER TO gb_user;

--
-- Name: video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gb_user
--

ALTER SEQUENCE public.video_id_seq OWNED BY public.video.id;


--
-- Name: disslikes id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.disslikes ALTER COLUMN id SET DEFAULT nextval('public.disslikes_id_seq'::regclass);


--
-- Name: likes id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.likes ALTER COLUMN id SET DEFAULT nextval('public.likes_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: photo id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.photo ALTER COLUMN id SET DEFAULT nextval('public.photo_id_seq'::regclass);


--
-- Name: publications id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.publications ALTER COLUMN id SET DEFAULT nextval('public.publikations_id_seq'::regclass);


--
-- Name: status id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.status ALTER COLUMN id SET DEFAULT nextval('public.status_id_seq'::regclass);


--
-- Name: subscriber id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.subscriber ALTER COLUMN id SET DEFAULT nextval('public.subscriber_id_seq'::regclass);


--
-- Name: subscription id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.subscription ALTER COLUMN id SET DEFAULT nextval('public.subscription_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: video id; Type: DEFAULT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.video ALTER COLUMN id SET DEFAULT nextval('public.video_id_seq'::regclass);


--
-- Data for Name: disslikes; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.disslikes (id, disslikes) FROM stdin;
\.


--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.likes (id, likes) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.messages (id, url, from_user_id, to_user_id, body, is_important, is_delivered, created_at) FROM stdin;
1	http://naver.com?q=4	8	1	tincidunt, neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo.	true	true	Oct 30, 2022
2	https://bbc.co.uk?search=1	9	2	nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet lobortis, nisi nibh	true	true	Apr 23, 2022
3	https://facebook.com?q=4	3	7	non magna. Nam ligula elit, pretium et, rutrum non, hendrerit id, ante. Nunc mauris sapien, cursus in, hendrerit consectetuer, cursus	true	false	May 29, 2022
4	http://bbc.co.uk?q=0	1	4	ullamcorper magna. Sed eu eros. Nam consequat dolor vitae dolor. Donec fringilla. Donec feugiat metus sit amet ante. Vivamus non	true	false	Apr 20, 2021
5	https://twitter.com?p=8	4	9	sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a,	true	false	Jun 4, 2022
6	https://twitter.com?q=4	0	1	ad litora torquent per conubia nostra, per inceptos hymenaeos. Mauris ut quam vel sapien imperdiet ornare. In faucibus. Morbi vehicula.	true	true	Jun 27, 2022
7	http://netflix.com?ad=115	3	5	fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida	false	true	Sep 4, 2022
8	http://facebook.com?q=test	6	4	montes, nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec	true	false	Jan 7, 2023
9	http://google.com?page=1&offset=1	9	8	lectus quis massa. Mauris vestibulum, neque sed dictum eleifend, nunc risus varius orci, in consequat enim diam vel arcu. Curabitur	true	true	May 26, 2022
10	https://instagram.com?ad=115	9	3	lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed	false	true	Apr 5, 2022
11	http://wikipedia.org?client=g	4	7	ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus. Quisque libero lacus, varius et, euismod et, commodo	false	false	Feb 17, 2022
12	http://nytimes.com?q=11	2	2	ac nulla. In tincidunt congue turpis. In condimentum. Donec at arcu. Vestibulum ante ipsum primis in faucibus orci luctus et	false	true	Dec 14, 2021
13	http://bbc.co.uk?search=1&q=de	4	6	eros. Proin ultrices. Duis volutpat nunc sit amet metus. Aliquam erat volutpat. Nulla facilisis. Suspendisse commodo tincidunt nibh. Phasellus nulla.	false	true	Jan 6, 2022
14	http://reddit.com?str=se	9	8	Aenean eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec	false	false	Feb 22, 2023
15	http://cnn.com?q=0	7	9	In nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim. Nunc	false	true	Aug 23, 2022
16	http://facebook.com?client=g	3	9	enim commodo hendrerit. Donec porttitor tellus non magna. Nam ligula elit, pretium et, rutrum non, hendrerit id, ante. Nunc mauris	false	false	Aug 17, 2022
17	http://zoom.us?search=1	6	6	nec, mollis vitae, posuere at, velit. Cras lorem lorem, luctus ut, pellentesque eget, dictum placerat, augue. Sed molestie. Sed id	false	true	Feb 24, 2023
18	https://naver.com?q=test	3	5	orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus dapibus quam quis diam.	false	true	Dec 5, 2021
19	https://instagram.com?p=8	7	0	risus. Donec nibh enim, gravida sit amet, dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient	true	false	Mar 6, 2023
20	https://yahoo.com?g=1	5	9	vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est. Nunc laoreet lectus quis	false	false	Nov 14, 2022
21	https://ebay.com?q=11	3	5	diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem lorem, luctus ut,	true	false	Dec 9, 2022
22	http://pinterest.com?page=1&offset=1	1	5	scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu,	false	true	Oct 23, 2021
23	https://youtube.com?q=4	5	9	mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus dapibus quam quis diam. Pellentesque habitant morbi tristique senectus et netus	false	false	Nov 17, 2021
24	http://walmart.com?q=0	1	9	gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis	true	false	Aug 6, 2022
25	http://yahoo.com?page=1&offset=1	3	7	et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis.	true	false	Apr 21, 2022
26	http://naver.com?ad=115	3	7	vestibulum. Mauris magna. Duis dignissim tempor arcu. Vestibulum ut eros non enim commodo hendrerit. Donec porttitor tellus non magna. Nam	false	true	Dec 4, 2022
27	http://pinterest.com?g=1	9	6	ut erat. Sed nunc est, mollis non, cursus non, egestas a, dui. Cras pellentesque. Sed dictum. Proin eget odio. Aliquam	true	true	Jun 22, 2022
28	http://zoom.us?p=8	5	5	eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero et tristique pellentesque, tellus sem	true	false	Jan 12, 2023
29	https://pinterest.com?q=test	5	3	arcu vel quam dignissim pharetra. Nam ac nulla. In tincidunt congue turpis. In condimentum. Donec at arcu. Vestibulum ante ipsum	true	true	Apr 2, 2022
30	http://cnn.com?str=se	5	5	per inceptos hymenaeos. Mauris ut quam vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus. Donec egestas.	true	true	Oct 12, 2021
31	http://naver.com?ab=441&aad=2	10	3	ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac arcu. Nunc mauris. Morbi non sapien molestie	true	true	May 24, 2021
32	https://naver.com?q=test	1	3	elit fermentum risus, at fringilla purus mauris a nunc. In at pede. Cras vulputate velit eu sem. Pellentesque ut ipsum	true	true	Mar 25, 2022
33	http://wikipedia.org?q=0	4	0	Duis risus odio, auctor vitae, aliquet nec, imperdiet nec, leo. Morbi neque tellus, imperdiet non, vestibulum nec, euismod in, dolor.	false	true	Dec 27, 2021
34	http://cnn.com?search=1&q=de	2	3	Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices	true	false	May 6, 2021
35	http://reddit.com?q=4	1	5	a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor	false	false	Oct 4, 2022
36	https://guardian.co.uk?search=1	5	9	blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae velit egestas lacinia. Sed congue, elit sed consequat auctor, nunc	true	false	Jun 26, 2022
37	https://wikipedia.org?ab=441&aad=2	2	7	vel, venenatis vel, faucibus id, libero. Donec consectetuer mauris id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis,	false	true	Jul 17, 2022
38	http://bbc.co.uk?q=11	5	10	nunc nulla vulputate dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla semper tellus	false	true	Mar 7, 2022
39	http://facebook.com?ad=115	7	5	Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu.	false	true	Jan 26, 2022
40	http://cnn.com?search=1	8	8	vitae nibh. Donec est mauris, rhoncus id, mollis nec, cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo	true	true	Jul 2, 2022
41	http://youtube.com?search=1	7	9	dapibus quam quis diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna	true	true	Jun 3, 2022
42	http://pinterest.com?client=g	4	6	Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum	true	false	Aug 3, 2021
43	http://guardian.co.uk?q=0	10	2	iaculis, lacus pede sagittis augue, eu tempor erat neque non quam. Pellentesque habitant morbi tristique senectus et netus et malesuada	false	true	Aug 27, 2022
44	https://zoom.us?q=11	3	0	faucibus orci luctus et ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus.	false	false	May 19, 2022
45	https://guardian.co.uk?k=0	7	8	varius ultrices, mauris ipsum porta elit, a feugiat tellus lorem eu metus. In lorem. Donec elementum, lorem ut aliquam iaculis,	false	true	Feb 21, 2023
46	https://bbc.co.uk?ab=441&aad=2	5	1	commodo hendrerit. Donec porttitor tellus non magna. Nam ligula elit, pretium et, rutrum non, hendrerit id, ante. Nunc mauris sapien,	true	false	Jan 25, 2023
47	http://bbc.co.uk?str=se	9	5	fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida	false	false	Aug 4, 2022
48	https://guardian.co.uk?page=1&offset=1	0	6	porttitor interdum. Sed auctor odio a purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis est, vitae sodales nisi	false	true	Mar 19, 2022
49	http://google.com?search=1	7	8	lacus vestibulum lorem, sit amet ultricies sem magna nec quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis dis	true	true	Aug 8, 2021
50	https://bbc.co.uk?ad=115	5	7	gravida. Aliquam tincidunt, nunc ac mattis ornare, lectus ante dictum mi, ac mattis velit justo nec ante. Maecenas mi felis,	false	true	Dec 30, 2021
51	https://netflix.com?q=0	6	6	neque sed sem egestas blandit. Nam nulla magna, malesuada vel, convallis in, cursus et, eros. Proin ultrices. Duis volutpat nunc	true	false	Aug 21, 2021
52	https://whatsapp.com?p=8	9	7	viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer	true	false	Nov 24, 2022
53	https://guardian.co.uk?page=1&offset=1	7	2	metus. In nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim.	true	false	Oct 24, 2021
54	http://baidu.com?ad=115	3	0	dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a,	true	false	Mar 23, 2023
55	http://zoom.us?gi=100	10	4	a, scelerisque sed, sapien. Nunc pulvinar arcu et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam	true	true	Apr 10, 2023
56	http://cnn.com?search=1&q=de	1	1	mauris ut mi. Duis risus odio, auctor vitae, aliquet nec, imperdiet nec, leo. Morbi neque tellus, imperdiet non, vestibulum nec,	false	true	Jul 31, 2022
57	https://walmart.com?g=1	2	8	ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet,	false	true	May 17, 2021
58	http://pinterest.com?client=g	6	3	Integer eu lacus. Quisque imperdiet, erat nonummy ultricies ornare, elit elit fermentum risus, at fringilla purus mauris a nunc. In	true	false	Jul 31, 2022
59	http://cnn.com?gi=100	9	9	eget varius ultrices, mauris ipsum porta elit, a feugiat tellus lorem eu metus. In lorem. Donec elementum, lorem ut aliquam	false	false	Dec 3, 2022
60	https://walmart.com?client=g	3	5	eu tellus eu augue porttitor interdum. Sed auctor odio a purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis	false	true	Mar 17, 2022
61	https://zoom.us?search=1&q=de	3	2	et pede. Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus	true	false	Jul 16, 2022
62	https://naver.com?str=se	5	4	sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac arcu. Nunc mauris. Morbi non	true	true	Nov 29, 2021
63	https://cnn.com?q=11	7	2	nec metus facilisis lorem tristique aliquet. Phasellus fermentum convallis ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat	false	false	Sep 5, 2021
64	http://cnn.com?k=0	2	0	in sodales elit erat vitae risus. Duis a mi fringilla mi lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy	false	true	Nov 17, 2022
65	https://walmart.com?q=test	1	10	tincidunt nibh. Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus.	false	true	Oct 19, 2022
66	https://reddit.com?p=8	4	5	Donec vitae erat vel pede blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae velit egestas lacinia. Sed congue,	true	true	Jul 25, 2022
67	https://twitter.com?search=1	6	7	Aliquam tincidunt, nunc ac mattis ornare, lectus ante dictum mi, ac mattis velit justo nec ante. Maecenas mi felis, adipiscing	true	true	Nov 16, 2022
68	http://whatsapp.com?p=8	2	2	Nullam enim. Sed nulla ante, iaculis nec, eleifend non, dapibus rutrum, justo. Praesent luctus. Curabitur egestas nunc sed libero. Proin	false	false	Jul 19, 2021
69	http://whatsapp.com?ab=441&aad=2	5	4	molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec,	false	true	May 8, 2022
70	http://nytimes.com?str=se	8	4	parturient montes, nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate	false	true	Mar 30, 2022
71	https://cnn.com?gi=100	8	2	dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla semper tellus id nunc interdum	false	true	Mar 22, 2022
72	https://netflix.com?q=4	6	8	egestas lacinia. Sed congue, elit sed consequat auctor, nunc nulla vulputate dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis.	true	true	Jul 16, 2021
73	http://walmart.com?q=test	10	1	vel pede blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae velit egestas lacinia. Sed congue, elit sed consequat	true	false	Nov 26, 2022
74	http://wikipedia.org?q=0	4	0	pede ac urna. Ut tincidunt vehicula risus. Nulla eget metus eu erat semper rutrum. Fusce dolor quam, elementum at, egestas	false	false	Jan 28, 2022
75	https://zoom.us?search=1	7	4	Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit.	false	false	Apr 14, 2022
76	https://youtube.com?q=4	8	6	ut odio vel est tempor bibendum. Donec felis orci, adipiscing non, luctus sit amet, faucibus ut, nulla. Cras eu tellus	false	false	Nov 2, 2022
77	https://nytimes.com?str=se	9	2	auctor velit. Aliquam nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet	true	true	Dec 25, 2021
78	https://google.com?gi=100	7	2	nunc. In at pede. Cras vulputate velit eu sem. Pellentesque ut ipsum ac mi eleifend egestas. Sed pharetra, felis eget	true	false	Jan 18, 2023
79	https://pinterest.com?client=g	3	0	auctor non, feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis eget, ipsum. Donec sollicitudin adipiscing ligula. Aenean	true	false	Aug 18, 2022
80	http://naver.com?search=1&q=de	8	1	et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus euismod urna.	true	false	Oct 24, 2022
81	https://pinterest.com?ab=441&aad=2	0	10	nisi nibh lacinia orci, consectetuer euismod est arcu ac orci. Ut semper pretium neque. Morbi quis urna. Nunc quis arcu	false	false	May 16, 2021
82	https://instagram.com?q=0	5	3	cubilia Curae Donec tincidunt. Donec vitae erat vel pede blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae velit	true	true	Aug 21, 2021
83	https://nytimes.com?q=0	6	2	ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis.	true	false	Apr 8, 2022
84	http://instagram.com?search=1	6	9	lectus rutrum urna, nec luctus felis purus ac tellus. Suspendisse sed dolor. Fusce mi lorem, vehicula et, rutrum eu, ultrices	true	false	Jan 24, 2022
85	http://pinterest.com?ad=115	2	8	et libero. Proin mi. Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae, aliquet nec, imperdiet nec, leo. Morbi	false	false	Dec 4, 2021
86	http://reddit.com?gi=100	9	4	varius. Nam porttitor scelerisque neque. Nullam nisl. Maecenas malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada	true	true	Mar 27, 2023
87	https://youtube.com?page=1&offset=1	5	6	tellus faucibus leo, in lobortis tellus justo sit amet nulla. Donec non justo. Proin non massa non ante bibendum ullamcorper.	true	true	Dec 18, 2022
88	http://reddit.com?q=4	8	8	Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices	false	false	Jul 24, 2021
89	http://facebook.com?g=1	8	5	ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla.	false	true	Feb 17, 2022
90	http://nytimes.com?q=11	9	1	venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec tempus, lorem fringilla ornare placerat, orci	false	true	May 18, 2021
91	http://pinterest.com?q=11	9	8	malesuada fringilla est. Mauris eu turpis. Nulla aliquet. Proin velit. Sed malesuada augue ut lacus. Nulla tincidunt, neque vitae semper	false	false	Dec 25, 2021
92	http://wikipedia.org?q=0	4	8	urna, nec luctus felis purus ac tellus. Suspendisse sed dolor. Fusce mi lorem, vehicula et, rutrum eu, ultrices sit amet,	true	false	Jul 6, 2021
93	https://walmart.com?page=1&offset=1	1	3	Etiam vestibulum massa rutrum magna. Cras convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt vehicula risus. Nulla eget	true	true	May 27, 2022
94	http://netflix.com?q=4	6	8	felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam adipiscing lobortis	true	true	Aug 15, 2022
95	http://youtube.com?page=1&offset=1	1	6	quis diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque.	true	false	Oct 8, 2022
96	http://ebay.com?search=1&q=de	2	7	eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla semper tellus id nunc interdum feugiat. Sed nec metus facilisis	false	false	Oct 8, 2021
97	http://cnn.com?gi=100	7	8	molestie in, tempus eu, ligula. Aenean euismod mauris eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui	false	true	Dec 5, 2022
98	https://wikipedia.org?q=4	1	3	risus. Quisque libero lacus, varius et, euismod et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat, lectus sit amet	false	true	Dec 28, 2021
99	https://facebook.com?ad=115	8	10	metus. In nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim.	false	false	Dec 20, 2022
100	http://walmart.com?g=1	2	2	convallis est, vitae sodales nisi magna sed dui. Fusce aliquam, enim nec tempus scelerisque, lorem ipsum sodales purus, in molestie	true	true	Dec 28, 2022
\.


--
-- Data for Name: photo; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.photo (id, url, owner_id, description, uploaded_at, size) FROM stdin;
1	http://pinterest.com?q=4	90	aliquet vel, vulputate eu, odio. Phasellus at augue id ante	01.31.22	2511
2	http://google.com?g=1	35	cursus et, eros. Proin ultrices. Duis volutpat nunc sit amet	11.23.21	6383
3	https://youtube.com?k=0	37	arcu iaculis enim, sit amet ornare lectus justo eu arcu.	05.07.22	245
4	http://google.com?q=11	8	fermentum convallis ligula. Donec luctus aliquet odio. Etiam ligula tortor,	10.23.21	4669
5	http://naver.com?search=1	61	consectetuer adipiscing elit. Aliquam auctor, velit eget laoreet posuere, enim	07.29.21	6944
6	http://naver.com?k=0	97	dis parturient montes, nascetur ridiculus mus. Proin vel arcu eu	08.25.22	4808
7	https://wikipedia.org?q=test	75	bibendum sed, est. Nunc laoreet lectus quis massa. Mauris vestibulum,	03.19.23	2335
8	https://guardian.co.uk?q=0	84	Nunc quis arcu vel quam dignissim pharetra. Nam ac nulla.	09.16.22	5424
9	http://baidu.com?ad=115	32	sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus	12.09.21	9685
10	https://whatsapp.com?search=1	70	mauris ut mi. Duis risus odio, auctor vitae, aliquet nec,	07.23.22	9374
11	http://netflix.com?k=0	28	nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim.	08.14.21	4229
12	http://walmart.com?client=g	65	commodo auctor velit. Aliquam nisl. Nulla eu neque pellentesque massa	04.02.23	7817
13	http://baidu.com?q=4	86	natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.	06.13.22	1060
14	https://baidu.com?p=8	80	Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non,	11.17.21	1773
15	https://nytimes.com?gi=100	67	Aliquam adipiscing lobortis risus. In mi pede, nonummy ut, molestie	05.28.21	4239
16	https://netflix.com?k=0	38	euismod mauris eu elit. Nulla facilisi. Sed neque. Sed eget	07.01.22	3966
17	https://guardian.co.uk?gi=100	67	neque. In ornare sagittis felis. Donec tempor, est ac mattis	03.22.23	6090
18	https://nytimes.com?search=1&q=de	94	Maecenas mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus.	02.24.22	6853
19	https://bbc.co.uk?client=g	94	Nunc sed orci lobortis augue scelerisque mollis. Phasellus libero mauris,	12.31.21	6089
20	https://wikipedia.org?client=g	60	suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis	04.09.22	5306
21	https://youtube.com?q=0	30	vitae diam. Proin dolor. Nulla semper tellus id nunc interdum	03.22.22	6876
22	http://instagram.com?page=1&offset=1	50	lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy ultricies	02.02.22	4285
23	http://google.com?str=se	36	aliquam adipiscing lacus. Ut nec urna et arcu imperdiet ullamcorper.	04.11.22	8886
24	https://ebay.com?search=1&q=de	72	urna. Nunc quis arcu vel quam dignissim pharetra. Nam ac	04.21.21	310
25	https://bbc.co.uk?gi=100	31	ac arcu. Nunc mauris. Morbi non sapien molestie orci tincidunt	09.18.22	5287
26	https://bbc.co.uk?page=1&offset=1	77	sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus	01.22.22	616
27	https://reddit.com?str=se	47	diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris. Integer	03.12.22	1072
28	https://facebook.com?q=0	96	euismod et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur	07.06.21	3912
29	https://reddit.com?search=1	74	vestibulum lorem, sit amet ultricies sem magna nec quam. Curabitur	05.15.21	5215
30	https://twitter.com?page=1&offset=1	61	nec ligula consectetuer rhoncus. Nullam velit dui, semper et, lacinia	01.13.22	159
31	https://whatsapp.com?q=0	10	Donec sollicitudin adipiscing ligula. Aenean gravida nunc sed pede. Cum	08.17.21	9350
32	https://naver.com?client=g	15	Quisque imperdiet, erat nonummy ultricies ornare, elit elit fermentum risus,	07.17.21	2816
33	http://guardian.co.uk?q=test	54	Ut nec urna et arcu imperdiet ullamcorper. Duis at lacus.	06.22.21	3405
34	https://naver.com?search=1&q=de	46	dictum placerat, augue. Sed molestie. Sed id risus quis diam	08.23.22	1051
35	https://yahoo.com?q=0	10	Cras lorem lorem, luctus ut, pellentesque eget, dictum placerat, augue.	12.07.22	5427
36	https://twitter.com?gi=100	99	Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris	06.11.21	9377
37	http://walmart.com?gi=100	86	ante dictum mi, ac mattis velit justo nec ante. Maecenas	10.11.21	2760
38	https://naver.com?search=1	16	arcu. Vestibulum ante ipsum primis in faucibus orci luctus et	07.22.21	5857
39	http://zoom.us?ad=115	19	luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec	01.29.22	2302
40	http://baidu.com?str=se	5	nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus	01.06.22	2767
41	https://youtube.com?g=1	40	quis turpis vitae purus gravida sagittis. Duis gravida. Praesent eu	04.11.23	6349
42	http://pinterest.com?k=0	72	magna a tortor. Nunc commodo auctor velit. Aliquam nisl. Nulla	05.24.22	6672
43	http://netflix.com?q=0	22	massa. Vestibulum accumsan neque et nunc. Quisque ornare tortor at	09.25.22	184
44	https://google.com?ab=441&aad=2	34	diam. Pellentesque habitant morbi tristique senectus et netus et malesuada	08.08.22	8136
45	http://reddit.com?p=8	77	fringilla. Donec feugiat metus sit amet ante. Vivamus non lorem	10.15.22	8189
46	https://pinterest.com?str=se	55	magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam	05.26.21	1080
47	https://ebay.com?page=1&offset=1	6	a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam	03.19.23	5982
48	http://twitter.com?ad=115	54	Vestibulum ante ipsum primis in faucibus orci luctus et ultrices	11.19.21	5244
49	https://ebay.com?search=1	3	elit, pretium et, rutrum non, hendrerit id, ante. Nunc mauris	04.21.21	7485
50	http://bbc.co.uk?q=11	59	bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna	07.07.21	3176
51	https://facebook.com?q=test	90	Nulla tincidunt, neque vitae semper egestas, urna justo faucibus lectus,	08.11.22	2600
52	http://baidu.com?search=1&q=de	93	mauris sit amet lorem semper auctor. Mauris vel turpis. Aliquam	12.11.21	8121
53	http://whatsapp.com?q=0	47	dignissim magna a tortor. Nunc commodo auctor velit. Aliquam nisl.	04.30.22	2497
54	https://nytimes.com?str=se	8	ut aliquam iaculis, lacus pede sagittis augue, eu tempor erat	04.18.23	5502
55	http://instagram.com?p=8	93	arcu ac orci. Ut semper pretium neque. Morbi quis urna.	05.10.21	7397
56	https://nytimes.com?page=1&offset=1	72	a mi fringilla mi lacinia mattis. Integer eu lacus. Quisque	06.18.22	4529
57	https://instagram.com?q=4	81	sed pede nec ante blandit viverra. Donec tempus, lorem fringilla	12.15.21	2926
58	https://wikipedia.org?page=1&offset=1	6	et magnis dis parturient montes, nascetur ridiculus mus. Donec dignissim	03.22.22	3770
59	http://twitter.com?str=se	64	quam vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque	01.21.23	7455
60	http://nytimes.com?page=1&offset=1	45	sit amet nulla. Donec non justo. Proin non massa non	07.30.21	2052
61	http://guardian.co.uk?k=0	1	Sed nec metus facilisis lorem tristique aliquet. Phasellus fermentum convallis	08.22.21	2999
62	http://guardian.co.uk?q=0	54	mollis dui, in sodales elit erat vitae risus. Duis a	10.01.22	8030
63	https://baidu.com?q=11	13	convallis convallis dolor. Quisque tincidunt pede ac urna. Ut tincidunt	12.28.22	9576
64	http://facebook.com?search=1	99	mollis lectus pede et risus. Quisque libero lacus, varius et,	07.10.21	5595
65	http://bbc.co.uk?ab=441&aad=2	46	elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar arcu	10.12.21	3127
66	https://wikipedia.org?search=1	69	tortor at risus. Nunc ac sem ut dolor dapibus gravida.	01.16.22	3761
67	http://twitter.com?q=4	26	at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque	07.18.22	6303
68	http://baidu.com?k=0	36	suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis	09.19.21	2005
69	https://cnn.com?g=1	61	Suspendisse aliquet molestie tellus. Aenean egestas hendrerit neque. In ornare	04.08.23	3827
70	https://wikipedia.org?client=g	20	Sed neque. Sed eget lacus. Mauris non dui nec urna	05.27.22	8994
71	https://walmart.com?search=1&q=de	71	ridiculus mus. Proin vel arcu eu odio tristique pharetra. Quisque	08.06.22	8162
72	http://cnn.com?ad=115	89	vel sapien imperdiet ornare. In faucibus. Morbi vehicula. Pellentesque tincidunt	02.18.23	3063
73	http://reddit.com?page=1&offset=1	71	iaculis, lacus pede sagittis augue, eu tempor erat neque non	02.12.22	5494
74	http://cnn.com?str=se	82	sit amet, consectetuer adipiscing elit. Aliquam auctor, velit eget laoreet	06.26.22	3437
75	http://yahoo.com?search=1&q=de	93	sagittis felis. Donec tempor, est ac mattis semper, dui lectus	01.08.23	5161
76	https://guardian.co.uk?page=1&offset=1	92	vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac arcu.	05.08.22	743
77	https://twitter.com?ad=115	33	et, lacinia vitae, sodales at, velit. Pellentesque ultricies dignissim lacus.	03.19.22	7535
78	https://netflix.com?q=test	23	eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis	02.25.22	8562
79	http://nytimes.com?p=8	85	Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris	07.25.22	9364
80	http://baidu.com?q=11	50	neque. In ornare sagittis felis. Donec tempor, est ac mattis	11.12.22	6283
81	https://baidu.com?gi=100	20	tellus id nunc interdum feugiat. Sed nec metus facilisis lorem	03.05.23	601
82	http://netflix.com?q=11	7	leo. Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis,	05.20.21	6890
83	http://naver.com?q=11	94	dictum magna. Ut tincidunt orci quis lectus. Nullam suscipit, est	08.27.22	8515
84	http://google.com?gi=100	12	gravida. Praesent eu nulla at sem molestie sodales. Mauris blandit	11.18.21	3172
85	http://facebook.com?search=1&q=de	96	lectus pede et risus. Quisque libero lacus, varius et, euismod	05.28.22	3025
86	https://nytimes.com?ad=115	67	sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis,	10.06.22	4210
87	http://facebook.com?q=11	97	at sem molestie sodales. Mauris blandit enim consequat purus. Maecenas	11.14.22	5005
88	http://naver.com?g=1	40	blandit enim consequat purus. Maecenas libero est, congue a, aliquet	10.19.22	8262
89	https://pinterest.com?str=se	90	aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a,	03.02.22	9197
90	https://google.com?q=4	20	libero mauris, aliquam eu, accumsan sed, facilisis vitae, orci. Phasellus	09.03.22	8955
91	http://youtube.com?search=1	12	vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu.	11.28.21	5419
92	http://yahoo.com?str=se	43	netus et malesuada fames ac turpis egestas. Aliquam fringilla cursus	03.11.23	2709
93	https://guardian.co.uk?client=g	96	mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed	12.05.21	598
94	http://ebay.com?ab=441&aad=2	89	metus sit amet ante. Vivamus non lorem vitae odio sagittis	09.01.22	5411
95	https://zoom.us?q=test	36	tempor lorem, eget mollis lectus pede et risus. Quisque libero	12.06.21	9803
96	https://google.com?p=8	95	enim mi tempor lorem, eget mollis lectus pede et risus.	07.09.21	6568
97	https://naver.com?search=1	0	eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in	03.18.22	9513
98	https://bbc.co.uk?q=0	55	Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris.	03.28.23	8405
99	https://ebay.com?g=1	2	lorem eu metus. In lorem. Donec elementum, lorem ut aliquam	03.30.22	9654
100	https://guardian.co.uk?page=1&offset=1	19	neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc	01.19.22	7044
\.


--
-- Data for Name: publications; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.publications (id, photo_id, video_id, descriptions, count_likes, count_disslikes) FROM stdin;
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.status (id, status_text) FROM stdin;
\.


--
-- Data for Name: subscriber; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.subscriber (id, name) FROM stdin;
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.subscription (id, requested_by_user_id, requested_to_user_id, status_id, requested_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.users (id, first_name, last_name, email, phone, main_photo_id, created_at) FROM stdin;
1	Shelley	Wells	dictum.placerat@icloud.ca	876-0774	11	04.09.22
2	Ria	Duffy	pharetra.sed@google.org	1-487-271-0433	89	06.22.21
3	Dylan	Caldwell	molestie.tellus@hotmail.couk	1-539-239-5556	29	11.15.22
4	Darryl	Acosta	molestie.orci.tincidunt@protonmail.com	1-741-663-0672	27	12.04.21
5	Erin	Goodman	natoque.penatibus@outlook.org	1-685-516-6617	50	10.24.21
6	Quemby	Talley	in.magna.phasellus@google.edu	789-2209	25	08.08.22
7	Beatrice	Knox	quis.turpis@aol.com	1-408-381-7541	87	06.10.21
8	Andrew	Taylor	vitae.orci.phasellus@google.org	682-4093	100	10.09.22
9	Colby	Ball	lorem.sit@icloud.ca	545-5613	85	12.21.22
10	Signe	Chandler	curabitur.ut.odio@google.edu	933-7462	10	03.01.23
11	Clare	Hart	dictum.magna@icloud.couk	1-424-467-3869	86	04.04.22
12	Hector	Young	aliquam.iaculis@outlook.edu	865-4845	8	06.28.21
13	Shana	Kemp	in.faucibus.morbi@aol.edu	1-128-777-4273	27	02.04.22
14	Vielka	England	nunc.commodo@google.com	686-3010	95	11.17.21
15	Shad	Bright	ornare@google.com	967-3644	24	09.29.21
16	Ferdinand	Willis	lacinia.sed@aol.edu	264-1118	82	04.10.23
17	Maggie	Stein	erat.eget@google.couk	1-240-233-6552	91	09.30.22
18	Neville	Munoz	augue.scelerisque@aol.ca	1-844-678-0384	24	12.18.21
19	Marny	Carr	mauris.vel@yahoo.ca	737-3434	45	06.12.22
20	Camden	Foster	neque.in.ornare@protonmail.com	1-758-823-8573	27	01.10.22
21	Robin	Johnson	dictum.augue.malesuada@hotmail.couk	1-686-858-4262	98	10.07.21
22	Britanney	Mcbride	semper.dui.lectus@aol.edu	1-222-634-5286	29	03.20.22
23	Germane	Hewitt	mauris.nulla@protonmail.couk	874-1175	70	12.28.22
24	Alan	Long	sociis.natoque@google.org	222-6279	49	12.29.21
25	Timothy	Weaver	mauris.eu@aol.edu	1-615-795-3721	1	07.21.22
26	Michelle	Lott	risus.at@outlook.couk	1-772-779-2849	24	03.17.23
27	Kylee	Davis	curabitur.ut.odio@outlook.com	633-0273	11	10.06.22
28	Azalia	Hanson	scelerisque.sed.sapien@protonmail.edu	1-834-827-9728	36	09.19.22
29	Preston	Stanton	molestie.orci.tincidunt@hotmail.net	361-2878	6	10.27.22
30	Jorden	Sharpe	in.mi.pede@icloud.edu	341-2787	82	06.18.22
31	Zephr	Farley	amet@outlook.couk	468-7110	19	10.03.22
32	Finn	Leonard	at.fringilla@google.net	1-691-507-3898	97	06.13.22
33	Gannon	Mcpherson	augue.porttitor@outlook.org	1-387-568-8366	3	10.24.22
34	Denton	Bartlett	velit.sed@icloud.org	584-2429	96	05.29.22
35	Martin	Perkins	a.magna.lorem@protonmail.ca	226-7413	52	04.29.22
36	Lesley	Brock	interdum.curabitur@hotmail.org	443-4295	68	05.31.21
37	Elaine	Donaldson	ipsum.cursus@outlook.org	691-4483	89	07.19.22
38	Holmes	Stevenson	mi.fringilla@aol.net	1-902-857-1606	42	09.06.22
39	Dalton	Donaldson	quis@outlook.net	1-544-425-6173	55	02.25.23
40	Uriel	Mcfadden	suspendisse.ac@hotmail.org	1-310-433-3802	45	03.06.22
41	Rhea	Reese	porttitor.eros.nec@icloud.net	1-622-281-4788	20	05.19.21
42	Kylie	Foley	quisque.varius@icloud.org	1-356-546-1314	90	06.20.21
43	Cally	Guerrero	elit@protonmail.edu	1-378-233-1518	72	03.16.22
44	Hanae	Weber	blandit.viverra.donec@google.ca	1-571-741-2775	74	06.17.21
45	Honorato	Logan	vel.arcu@icloud.ca	662-1331	50	10.17.21
46	James	Harmon	duis@yahoo.net	1-866-743-7362	8	02.28.23
47	Sophia	Stephenson	blandit.at.nisi@aol.org	1-613-863-5457	34	06.08.22
48	Holly	Guthrie	quam.elementum@icloud.org	771-6684	89	10.10.21
49	Carson	Lowery	ac.eleifend@yahoo.edu	1-432-606-8288	44	03.27.22
50	Bevis	James	ac.sem@google.ca	1-763-547-3066	32	08.31.22
51	Magee	Adkins	fringilla.est@aol.ca	1-629-821-6166	17	01.19.22
52	Colt	Wyatt	montes@aol.com	708-2685	21	07.20.22
53	Nero	Haley	consequat.lectus.sit@icloud.com	436-4244	20	01.03.22
54	Akeem	Valdez	sed@outlook.edu	219-3686	47	03.11.22
55	Jack	Downs	mauris.a.nunc@aol.net	747-0932	5	05.10.21
56	Chloe	Morrison	urna.nullam.lobortis@hotmail.net	1-553-708-5529	38	02.16.23
57	Timon	Spears	a.auctor@protonmail.couk	1-559-463-6654	88	08.13.21
58	Hall	Lee	mollis.phasellus@google.couk	277-4165	63	11.13.22
59	Kadeem	Welch	auctor.velit.aliquam@icloud.com	999-0123	91	07.20.22
60	Oprah	Ware	mauris.morbi@outlook.couk	523-9954	64	02.16.22
61	Brady	Gillespie	id.risus@protonmail.edu	1-385-662-1686	84	05.10.22
62	Marcia	Meyer	sit.amet.risus@yahoo.org	1-851-454-7713	69	09.17.21
63	Lisandra	Garrett	sem@icloud.edu	692-4411	65	12.03.21
64	Leila	French	laoreet.libero@icloud.com	231-9054	21	12.23.21
65	Hilary	Lucas	gravida.sagittis@outlook.ca	961-5784	34	11.17.22
66	Dorian	Roach	fermentum@icloud.couk	856-7562	1	06.09.22
67	Owen	White	pede.ac@google.couk	1-747-418-7895	67	11.18.21
68	Ferris	Walker	metus@hotmail.org	852-3534	66	12.23.21
69	Fuller	Hanson	tristique.pellentesque.tellus@icloud.edu	1-606-471-2803	39	02.21.23
70	Lareina	Mcneil	gravida@yahoo.edu	661-8817	63	05.15.22
71	Jacob	Sweet	pede.malesuada@hotmail.net	550-0722	17	04.01.22
72	Althea	Hahn	erat.sed.nunc@icloud.ca	250-5264	36	12.25.22
73	Tamekah	Holmes	vel.nisl@google.ca	1-481-372-4583	11	11.28.22
74	Josiah	Copeland	ultricies.adipiscing.enim@outlook.couk	896-5697	50	06.23.21
75	Dillon	Dennis	ut.nulla@yahoo.edu	279-6711	85	04.18.23
76	Rina	Carter	hendrerit.a@hotmail.couk	1-614-122-7960	98	09.26.22
77	Joan	English	sit.amet@protonmail.ca	997-0244	79	10.22.21
78	Len	Oneil	iaculis@hotmail.edu	1-904-701-7589	59	04.10.23
79	Zenia	Nelson	ultricies@protonmail.couk	861-3615	15	08.06.22
80	Uriah	Dickson	malesuada.vel.venenatis@icloud.net	1-828-383-2288	65	02.22.22
81	Christine	Phillips	sem.elit.pharetra@protonmail.com	1-221-990-7408	61	05.10.22
82	Shaeleigh	Gay	commodo.ipsum@outlook.net	387-8513	41	10.19.21
83	Lester	Knox	integer.vitae@hotmail.edu	125-5101	67	06.24.22
84	Medge	Horne	blandit.mattis@outlook.couk	674-4049	90	10.01.22
85	Uta	Kelly	feugiat.non@outlook.net	368-6207	68	08.24.22
86	Dustin	Sweet	nullam@icloud.net	1-252-589-8275	74	10.27.21
87	Fay	Nguyen	nec.diam.duis@google.ca	1-229-983-6322	37	06.25.22
88	Desirae	Eaton	arcu.sed.et@yahoo.edu	1-456-805-9756	61	05.17.21
89	Bianca	Valenzuela	semper@protonmail.com	575-8255	95	09.03.22
90	Adam	Deleon	dictum.mi@google.net	1-506-666-5837	7	12.20.22
91	Lillian	Chavez	ut@protonmail.com	1-552-744-8784	65	02.20.23
92	Louis	Decker	nec.quam.curabitur@google.couk	341-7855	66	12.07.22
93	Christine	Nolan	metus@hotmail.edu	1-249-366-3370	49	12.09.22
94	Lane	Carney	dignissim.lacus.aliquam@hotmail.couk	250-5435	21	11.06.22
95	Camilla	Conrad	malesuada@yahoo.edu	1-651-397-6672	15	05.02.22
96	Kevin	Sullivan	at.augue@protonmail.net	168-5305	66	07.17.21
97	Marah	Moses	mi.aliquam.gravida@protonmail.ca	1-651-274-0307	27	06.06.21
98	Danielle	Barron	in.magna.phasellus@aol.edu	1-889-188-2244	14	04.17.22
99	Tatiana	Goodwin	ullamcorper.eu@icloud.couk	1-833-180-7735	7	01.29.23
100	Justina	Hicks	mauris@yahoo.couk	698-3734	62	02.12.22
\.


--
-- Data for Name: video; Type: TABLE DATA; Schema: public; Owner: gb_user
--

COPY public.video (id, url, owner_id, description, uploaded_at, size) FROM stdin;
1	https://yahoo.com?ad=115	44	pellentesque. Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper magna.	03.05.22	8872
2	http://naver.com?k=0	3	est tempor bibendum. Donec felis orci, adipiscing non, luctus sit	05.29.21	5459
3	http://zoom.us?search=1&q=de	6	fringilla ornare placerat, orci lacus vestibulum lorem, sit amet ultricies	01.03.22	1909
4	https://twitter.com?q=4	38	scelerisque mollis. Phasellus libero mauris, aliquam eu, accumsan sed, facilisis	05.21.22	750
5	http://netflix.com?ab=441&aad=2	71	purus mauris a nunc. In at pede. Cras vulputate velit	08.24.22	1928
6	http://pinterest.com?ad=115	83	Morbi neque tellus, imperdiet non, vestibulum nec, euismod in, dolor.	04.25.22	7633
7	https://ebay.com?gi=100	31	metus. Aliquam erat volutpat. Nulla facilisis. Suspendisse commodo tincidunt nibh.	01.04.23	4784
8	http://twitter.com?q=test	13	nonummy ultricies ornare, elit elit fermentum risus, at fringilla purus	08.28.21	7120
9	https://wikipedia.org?g=1	94	consequat auctor, nunc nulla vulputate dui, nec tempus mauris erat	12.31.21	3364
10	http://baidu.com?p=8	33	Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum	02.03.23	1229
11	https://facebook.com?gi=100	39	faucibus orci luctus et ultrices posuere cubilia Curae Phasellus ornare.	04.19.23	1046
12	http://wikipedia.org?str=se	7	Pellentesque habitant morbi tristique senectus et netus et malesuada fames	09.07.22	1502
13	https://twitter.com?k=0	59	rutrum lorem ac risus. Morbi metus. Vivamus euismod urna. Nullam	06.26.21	1029
14	http://guardian.co.uk?search=1&q=de	90	ac mattis ornare, lectus ante dictum mi, ac mattis velit	08.24.21	3006
15	https://reddit.com?p=8	34	non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper	01.08.23	4315
16	https://zoom.us?search=1	51	tellus non magna. Nam ligula elit, pretium et, rutrum non,	06.17.21	123
17	https://zoom.us?q=4	36	turpis nec mauris blandit mattis. Cras eget nisi dictum augue	06.10.22	1151
18	http://baidu.com?search=1&q=de	7	Mauris vel turpis. Aliquam adipiscing lobortis risus. In mi pede,	12.23.22	6907
19	http://guardian.co.uk?q=11	55	Nulla eget metus eu erat semper rutrum. Fusce dolor quam,	05.18.21	1760
20	http://netflix.com?client=g	19	blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae	05.26.22	1081
21	http://whatsapp.com?client=g	58	urna. Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis	02.18.22	9753
22	https://baidu.com?q=4	100	dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum	12.07.22	8064
23	http://guardian.co.uk?ab=441&aad=2	95	luctus, ipsum leo elementum sem, vitae aliquam eros turpis non	04.18.22	6025
24	https://ebay.com?g=1	11	pharetra nibh. Aliquam ornare, libero at auctor ullamcorper, nisl arcu	01.20.22	7965
25	http://naver.com?page=1&offset=1	100	luctus aliquet odio. Etiam ligula tortor, dictum eu, placerat eget,	06.22.22	2007
26	https://instagram.com?q=11	96	leo elementum sem, vitae aliquam eros turpis non enim. Mauris	02.14.23	7534
27	https://naver.com?p=8	61	lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis	01.20.23	3495
28	http://yahoo.com?k=0	46	faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend.	02.06.23	6110
29	http://naver.com?q=11	11	ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit	05.24.21	952
30	http://baidu.com?page=1&offset=1	73	ornare, elit elit fermentum risus, at fringilla purus mauris a	08.09.22	8016
31	https://ebay.com?q=4	55	malesuada vel, convallis in, cursus et, eros. Proin ultrices. Duis	08.16.21	8648
32	http://walmart.com?q=0	39	eu enim. Etiam imperdiet dictum magna. Ut tincidunt orci quis	11.01.22	9075
33	https://guardian.co.uk?q=test	25	sit amet ante. Vivamus non lorem vitae odio sagittis semper.	11.16.22	1108
34	http://youtube.com?str=se	24	dolor elit, pellentesque a, facilisis non, bibendum sed, est. Nunc	05.19.21	5979
35	http://bbc.co.uk?search=1	13	arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum	03.21.23	2068
36	https://netflix.com?search=1	15	Fusce aliquet magna a neque. Nullam ut nisi a odio	04.30.22	4037
37	https://baidu.com?k=0	86	sem ut dolor dapibus gravida. Aliquam tincidunt, nunc ac mattis	08.24.21	5756
38	http://google.com?k=0	2	felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit	08.01.21	1814
39	http://google.com?ad=115	24	quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod	02.20.23	2394
40	https://guardian.co.uk?q=test	21	Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede.	12.30.22	5535
41	http://youtube.com?q=test	17	dui. Cum sociis natoque penatibus et magnis dis parturient montes,	05.03.21	5650
42	http://facebook.com?search=1	84	tellus. Phasellus elit pede, malesuada vel, venenatis vel, faucibus id,	01.08.22	2808
43	https://google.com?gi=100	87	rutrum eu, ultrices sit amet, risus. Donec nibh enim, gravida	01.29.22	9321
44	https://facebook.com?k=0	26	elit pede, malesuada vel, venenatis vel, faucibus id, libero. Donec	10.09.22	4864
45	http://pinterest.com?k=0	76	felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit	03.29.22	751
46	http://nytimes.com?page=1&offset=1	28	in faucibus orci luctus et ultrices posuere cubilia Curae Phasellus	12.25.21	2110
47	http://facebook.com?str=se	78	ac facilisis facilisis, magna tellus faucibus leo, in lobortis tellus	05.27.21	388
48	https://yahoo.com?g=1	36	ac metus vitae velit egestas lacinia. Sed congue, elit sed	04.16.23	3100
49	http://guardian.co.uk?q=0	88	tellus lorem eu metus. In lorem. Donec elementum, lorem ut	12.13.21	5551
50	https://google.com?g=1	72	risus. Morbi metus. Vivamus euismod urna. Nullam lobortis quam a	03.01.22	3701
51	http://youtube.com?p=8	21	dolor sit amet, consectetuer adipiscing elit. Aliquam auctor, velit eget	11.04.22	3759
52	http://facebook.com?q=4	81	vitae, posuere at, velit. Cras lorem lorem, luctus ut, pellentesque	06.17.22	4889
53	http://wikipedia.org?g=1	18	hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida	09.25.21	5368
54	https://yahoo.com?search=1&q=de	69	Proin vel arcu eu odio tristique pharetra. Quisque ac libero	07.02.22	7900
55	https://netflix.com?q=0	32	lobortis. Class aptent taciti sociosqu ad litora torquent per conubia	04.21.22	8346
56	http://wikipedia.org?p=8	90	dignissim lacus. Aliquam rutrum lorem ac risus. Morbi metus. Vivamus	12.31.21	7544
57	https://baidu.com?ad=115	28	et malesuada fames ac turpis egestas. Fusce aliquet magna a	04.22.22	2473
58	https://facebook.com?p=8	89	ac urna. Ut tincidunt vehicula risus. Nulla eget metus eu	02.18.23	1665
59	https://yahoo.com?q=11	79	purus, in molestie tortor nibh sit amet orci. Ut sagittis	06.22.21	8465
60	http://yahoo.com?search=1&q=de	31	ullamcorper eu, euismod ac, fermentum vel, mauris. Integer sem elit,	12.13.21	8132
61	http://netflix.com?page=1&offset=1	72	arcu. Morbi sit amet massa. Quisque porttitor eros nec tellus.	01.14.22	2788
62	http://facebook.com?ab=441&aad=2	16	sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem	12.06.22	9667
63	http://google.com?gi=100	25	gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat.	07.15.21	8169
64	http://pinterest.com?client=g	47	Curabitur sed tortor. Integer aliquam adipiscing lacus. Ut nec urna	05.04.21	4154
65	https://walmart.com?ab=441&aad=2	85	dictum augue malesuada malesuada. Integer id magna et ipsum cursus	07.05.22	2660
66	http://bbc.co.uk?k=0	99	Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris	12.06.21	6559
67	http://cnn.com?q=0	29	vestibulum massa rutrum magna. Cras convallis convallis dolor. Quisque tincidunt	10.12.21	5769
68	https://naver.com?q=4	53	Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet,	11.21.22	7760
69	https://facebook.com?q=11	71	Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede.	10.20.22	3960
70	https://zoom.us?q=0	32	ligula. Donec luctus aliquet odio. Etiam ligula tortor, dictum eu,	09.17.22	120
71	https://youtube.com?str=se	27	luctus lobortis. Class aptent taciti sociosqu ad litora torquent per	01.13.23	6717
72	https://ebay.com?q=4	20	malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis.	10.31.21	4487
73	https://facebook.com?q=4	70	placerat, augue. Sed molestie. Sed id risus quis diam luctus	01.31.23	1090
74	http://reddit.com?gi=100	61	mi lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy	02.08.23	5543
75	http://netflix.com?p=8	63	tortor at risus. Nunc ac sem ut dolor dapibus gravida.	03.02.22	3078
76	https://reddit.com?search=1&q=de	90	ultrices posuere cubilia Curae Phasellus ornare. Fusce mollis. Duis sit	10.23.21	2508
77	http://whatsapp.com?g=1	55	non lorem vitae odio sagittis semper. Nam tempor diam dictum	12.09.21	9248
78	https://zoom.us?k=0	60	bibendum. Donec felis orci, adipiscing non, luctus sit amet, faucibus	05.12.21	4205
79	https://wikipedia.org?q=4	21	convallis, ante lectus convallis est, vitae sodales nisi magna sed	10.27.22	788
80	https://bbc.co.uk?ab=441&aad=2	28	sem, vitae aliquam eros turpis non enim. Mauris quis turpis	01.18.22	3921
81	https://zoom.us?page=1&offset=1	36	quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis	02.16.22	338
82	http://yahoo.com?q=4	70	mollis lectus pede et risus. Quisque libero lacus, varius et,	10.02.22	9077
83	http://youtube.com?ad=115	51	nonummy. Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in	02.26.22	4517
84	https://wikipedia.org?search=1	39	ut, pharetra sed, hendrerit a, arcu. Sed et libero. Proin	02.21.23	5323
85	http://zoom.us?gi=100	2	Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae,	10.01.21	2550
86	https://google.com?q=test	74	pellentesque eget, dictum placerat, augue. Sed molestie. Sed id risus	02.20.22	8409
87	http://walmart.com?gi=100	77	Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec	11.18.21	1596
88	https://instagram.com?ad=115	70	enim, gravida sit amet, dapibus id, blandit at, nisi. Cum	08.06.21	7186
89	http://twitter.com?p=8	80	Ut sagittis lobortis mauris. Suspendisse aliquet molestie tellus. Aenean egestas	01.07.23	8880
90	https://instagram.com?ab=441&aad=2	40	lobortis. Class aptent taciti sociosqu ad litora torquent per conubia	12.01.22	9116
91	https://whatsapp.com?client=g	64	magna et ipsum cursus vestibulum. Mauris magna. Duis dignissim tempor	05.16.21	5494
92	http://guardian.co.uk?g=1	49	Duis gravida. Praesent eu nulla at sem molestie sodales. Mauris	11.11.22	991
93	https://wikipedia.org?client=g	33	ridiculus mus. Donec dignissim magna a tortor. Nunc commodo auctor	06.30.22	8127
94	http://google.com?q=0	19	blandit congue. In scelerisque scelerisque dui. Suspendisse ac metus vitae	06.02.21	9396
95	http://wikipedia.org?k=0	47	odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam	07.31.21	6684
96	http://bbc.co.uk?gi=100	4	in sodales elit erat vitae risus. Duis a mi fringilla	10.07.21	8509
97	http://bbc.co.uk?search=1	26	odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a,	02.28.23	9593
98	http://ebay.com?ab=441&aad=2	17	a, malesuada id, erat. Etiam vestibulum massa rutrum magna. Cras	05.06.21	4220
99	https://nytimes.com?q=0	75	ante dictum cursus. Nunc mauris elit, dictum eu, eleifend nec,	09.11.22	4608
100	https://ebay.com?q=0	42	interdum enim non nisi. Aenean eget metus. In nec orci.	09.30.22	68
\.


--
-- Name: disslikes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.disslikes_id_seq', 1, false);


--
-- Name: likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.likes_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.messages_id_seq', 100, true);


--
-- Name: photo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.photo_id_seq', 100, true);


--
-- Name: publikations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.publikations_id_seq', 1, false);


--
-- Name: status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.status_id_seq', 1, false);


--
-- Name: subscriber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.subscriber_id_seq', 1, false);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.subscription_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.users_id_seq', 100, true);


--
-- Name: video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gb_user
--

SELECT pg_catalog.setval('public.video_id_seq', 100, true);


--
-- Name: disslikes disslikes_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.disslikes
    ADD CONSTRAINT disslikes_pkey PRIMARY KEY (id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: photo photo_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.photo
    ADD CONSTRAINT photo_pkey PRIMARY KEY (id);


--
-- Name: publications publikations_descriptions_key; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publikations_descriptions_key UNIQUE (descriptions);


--
-- Name: publications publikations_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.publications
    ADD CONSTRAINT publikations_pkey PRIMARY KEY (id);


--
-- Name: status status_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pkey PRIMARY KEY (id);


--
-- Name: status status_status_text_key; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_status_text_key UNIQUE (status_text);


--
-- Name: subscriber subscriber_name_key; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.subscriber
    ADD CONSTRAINT subscriber_name_key UNIQUE (name);


--
-- Name: subscriber subscriber_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.subscriber
    ADD CONSTRAINT subscriber_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: video video_pkey; Type: CONSTRAINT; Schema: public; Owner: gb_user
--

ALTER TABLE ONLY public.video
    ADD CONSTRAINT video_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

